//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by HW1.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_HW1TYPE                     130
#define PARAMETERS_DIALOG               310
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT3                       1002
#define IDC_BUTTON1                     1003
#define IDC_BUTTON2                     1004
#define IDC_BUTTON3                     1005
#define btn_test                        1005
#define ID_FILE_OPENPARAMETERSDIALOG    32771
#define ID_MODE_VALUES                  32772
#define ID_MODE_ZEROS                   32773
#define ID_TEST                         32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
